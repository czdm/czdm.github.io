NREUM.setToken({
    'stn': 0,
    'err': 1,
    'ins': 1,
    'spa': 1
})