var __languages__ = {
    "localizedValidationMessages": {
        "required": "\u6b64\u5b57\u6bb5\u4e3a\u5fc5\u586b\u5b57\u6bb5",
        "Email": "\u6b64\u5b57\u6bb5\u5fc5\u987b\u4e3a\u6709\u6548\u7684\u7535\u5b50\u90ae\u4ef6\u5730\u5740"
    }
};